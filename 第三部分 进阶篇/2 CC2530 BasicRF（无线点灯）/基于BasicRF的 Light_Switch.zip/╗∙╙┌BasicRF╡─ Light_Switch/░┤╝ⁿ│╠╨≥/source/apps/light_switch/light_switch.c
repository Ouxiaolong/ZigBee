/*******************************************************************************
*�ļ���   �� light_switch.c
*ʵ�ֹ��� �� ����BasicRF������light_switch
*Ӳ������ �� LED1 P1_0  
             LED2 P1_1
          
             KEY1 P0_4
             KEY2 P0_5
*����     �� fire 
*����ʱ�� �� 2015/xx/xx
*******************************************************************************/

#include <hal_assert.h>
#include <hal_board.h>
#include <hal_int.h>
#include "hal_mcu.h"
#include "hal_rf.h"
#include "basic_rf.h"
#include "hal.h"


/***********************************************************************************
* CONSTANTS
*/
// Application parameters
#define RF_CHANNEL                25      // 2.4 GHz RF channel

// BasicRF address definitions
#define PAN_ID                0x2007
#define SWITCH_ADDR           0x2520
#define LIGHT_ADDR            0xBEEF
#define APP_PAYLOAD_LENGTH        1

// Application states
#define IDLE                      0
#define SEND_CMD                  1

// Application role
#define NONE                      0
#define SWITCH                    1
#define LIGHT                     2
#define APP_MODES                 2

/***********************************************************************************
* LOCAL VARIABLES
*/
static uint8 pTxData[APP_PAYLOAD_LENGTH];
static basicRfCfg_t basicRfConfig;

static void appSwitch(void)
{  
    basicRfConfig.myAddr = SWITCH_ADDR; // Initialize BasicRF
    if(basicRfInit(&basicRfConfig)==FAILED) { //��ʼ��basicRf���ݽṹ
      HAL_ASSERT(FALSE);
    }           
    basicRfReceiveOff(); // Keep Receiver off when not needed to save power
    while (1) {
      if(KEY1==0){  // if S1 is detected
        pTxData[0] = 1;  //  Load data    
        basicRfSendPacket(LIGHT_ADDR, pTxData, APP_PAYLOAD_LENGTH);  // sent data         
        halIntOff(); // Put MCU to sleep. 
        halMcuSetLowPowerMode(HAL_MCU_LPM_3); // Will turn on global          
        halIntOn(); // interrupt enable
        LED1=0;
        halMcuWaitMs(300);  // Key delay
        LED1=1;
        }
      if(KEY2==0){  // if S2 is detected
        pTxData[0] = 2;  //  Load data    
        basicRfSendPacket(LIGHT_ADDR, pTxData, APP_PAYLOAD_LENGTH);  // sent data         
        halIntOff(); // Put MCU to sleep. 
        halMcuSetLowPowerMode(HAL_MCU_LPM_3); // Will turn on global          
        halIntOn(); // interrupt enable
        LED2=0;
        halMcuWaitMs(300);  // Key delay
        LED2=1;
        }
    }
}

void main(void)
{
    // Config basicRF
    basicRfConfig.panId = PAN_ID;      //������ID
    basicRfConfig.channel = RF_CHANNEL;//��Ƶͨ��
    basicRfConfig.ackRequest = TRUE;   //Ŀ��ȷ��

    halBoardInit();  //ʱ�ӡ��жϳ�ʼ��
    Initial_IO();    //IO��ʼ��

    // Initalise hal_rf
    if(halRfInit()==FAILED) {  //Э���ʼ��
      HAL_ASSERT(FALSE);
    }

     appSwitch();  // ������Ϣ���ͺ���(��ѭ��)

    HAL_ASSERT(FALSE);//����ִ�д˺���
}



/*********************************************END OF FILE**********************/


