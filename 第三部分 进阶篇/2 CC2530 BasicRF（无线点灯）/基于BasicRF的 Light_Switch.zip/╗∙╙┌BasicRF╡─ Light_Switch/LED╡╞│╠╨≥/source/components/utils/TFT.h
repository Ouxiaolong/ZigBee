/**************************************************
*�ļ���   �� TFT.h
*ʵ�ֹ��� ��  
*Ӳ������ ��  
*����     �� Cavani
*����ʱ�� �� 2013/8/4
*��ϵ��ʽ �� QQ:449199327
***************************************************/

#ifndef __TFT_H
#define	__TFT_H

#include <ioCC2530.h>
#include <string.h>


#define uint unsigned int 
#define uchar unsigned char
#define ushort unsigned short

#define ON 1
#define OFF 0

#define  BackgroundLED(a) if(a)\
                              BL=1;\
                              else\
                              BL=0
//Ĭ�ϳ������˵����
#define  cs     P1_2  //Ƭѡ
#define  reset  P1_1  //��λ,0��λ
#define  rs     P0_0  //1д���ݣ�0дָ��
#define  sda    P1_6  //����, MCU_P0.5 MOSI	��Ӧ��Һ����(����ģ��)TFT --SDA
#define  scl    P1_5  //ʱ��
//#define  BL     P0_7  //�����,��ֱ�ӽ�3.3V
//#define  LCD_SDO    P1_7  //���ݣ�MCU_P1.7 MISO ��Ӧ��Һ����(����ģ��)TFT --SDO

//��ɫ����˵��
#define White          0xFFFF
#define Black          0x0000
#define Blue           0x001F
#define Blue2          0x051F //ǳ��
#define Red            0xF800
#define Magenta        0xF81F
#define Green          0x07E0
#define Cyan           0x7FFF
#define Yellow         0xFFE0
#define GRAY0   0xEF7D   	//��ɫ0 3165 00110 001011 00101
#define GRAY1   0x8410      	//��ɫ1      00000 000000 00000
#define GRAY2   0x4208      	//��ɫ2  1111111111011111


void Delayms(uint xms) ;
void delay(uint time);
void SetSysClock(void);
void IO_Init(void);
void Reset(void);
void write_command(uchar command);
void write_data(uchar data);
void wr_dat16(uchar i,uchar j);
void wr_dat(uint dat);
void TFT_Initialize(void);
void Set_Address(uint X,uint Y);
void  RamAdressSet(void);
void TFT_SetPos(uint x0,uint x1,uint y0,uint y1);
void dsp_single_colour_1(uchar DH,uchar DL);//1---����
void dsp_single_colour_2(uchar DH,uchar DL);//2---����
void Screen_Show_Colour_1(uint colour);//1---����
void Screen_Show_Colour_2(uint colour);//2---����
void TFT_PutChar(ushort x, ushort y, char c, uint fColor, uint bColor);
void TFT_PutChar8x16(ushort x, ushort y, char c, uint fColor, uint bColor);
void TFT_PutString_1616(ushort x, ushort y, uchar *s, uint fColor, uint bColor);
void PutGB1616(ushort x, ushort y, uchar c[2], uint fColor,uint bColor);
void PutGB2424(ushort x, ushort  y, uchar c[2], uint fColor,uint bColor);
void PutGB3232(ushort x, ushort  y, uchar c[2], uint fColor,uint bColor);
void TFT_PutString_2424(ushort x, ushort y, uchar *s, uint fColor, uint bColor); 
void TFT_PutString_3232(ushort x, ushort y, uchar *s, uint fColor, uint bColor);
void TFT_DrawPoint(uint x,uint y,uint Data);
void TFT_DrawFont_Num32(uint x, uint y, uint fc, uint bc, uint num);
void ShowPicture(const uchar *p);

#endif 

/******** (C) COPYRIGHT 2013 Cavani *****END OF FILE****/
