/***********************************************************************************

  Filename:     hal_board.h

  Description:  SmartRF05 board with CCxxxxEM.

***********************************************************************************/

#ifndef HAL_BOARD_H
#define HAL_BOARD_H

#include "hal_cc8051.h"
#include "hal_defs.h"
#include "hal_mcu.h"
#include "ioCC2530.h"

#define BSP_CONFIG_CLOCK_MHZ                32



/***********************************************************************************
 * CONSTANTS
 */

// add by Cavani
#define KEY1 P0_1      //KEY1ΪP0.1�ڿ���
#define KEY2 P2_0      //

#define LED1     P1_0    //P1.0���Ӻ�ɫLED
#define LED2     P1_1    //P1.1������ɫLED


// Board properties
#define BOARD_NAME                     "SRF05EB"

#define HAL_BOARD_IO_UART_RTS_PORT          0
#define HAL_BOARD_IO_UART_RTS_PIN           5


// Debounce
#define HAL_DEBOUNCE(expr)    { int i; for (i=0; i<500; i++) { if (!(expr)) i = 0; } }

/***********************************************************************************
 * MACROS
 */


#define HAL_RTS_SET()       MCU_IO_SET_HIGH(HAL_BOARD_IO_UART_RTS_PORT, \
    HAL_BOARD_IO_UART_RTS_PIN)
#define HAL_RTS_CLR()       MCU_IO_SET_LOW(HAL_BOARD_IO_UART_RTS_PORT, \
    HAL_BOARD_IO_UART_RTS_PIN)
#define HAL_RTS_DIR_OUT()   MCU_IO_OUTPUT(HAL_BOARD_IO_UART_RTS_PORT, \
    HAL_BOARD_IO_UART_RTS_PIN, 1)



#define HAL_PROCESS()

/***********************************************************************************
 * FUNCTION PROTOTYPES
 */
void halBoardInit(void);
void Initial_IO();

#endif
