/***********************************************************************************
  Filename:     hal_board.c

  Description:  HAL board peripherals library for the
                SmartRF05EB + CC2430EM/CC2531EM/CC2510/CC1110 platforms

***********************************************************************************/

/***********************************************************************************
* INCLUDES
*/
#include "hal_types.h"
#include "hal_defs.h"
#include "hal_digio.h"
#include "hal_int.h"
#include "hal_mcu.h"
#include "hal_board.h"
#include "clock.h"

#define SPI_CLOCK_POL_LO       0x00
#define SPI_CLOCK_POL_HI       0x80
#define SPI_CLOCK_PHA_0        0x00
#define SPI_CLOCK_PHA_1        0x40
#define SPI_TRANSFER_MSB_FIRST 0x20
#define SPI_TRANSFER_MSB_LAST  0x00

#define KEY1 P0_1      //KEY1ΪP0.1�ڿ���
#define KEY2 P2_0      //

#define LED1     P1_0    //P1.0���Ӻ�ɫLED
#define LED2     P1_1    //P1.1������ɫLED


/****************************
     ������ʼ������
*****************************/
void Initial_IO(void)
{
    P1DIR |= 0x03;     
    LED1=1;
    LED2=1;

} 

void halBoardInit(void)
{
    halMcuInit();
    halIntOn();
}

